<?php 

require_once '../app/init.php';
require_once '../app/core/App.php'; 


$app = new App();
$app->run();

?>