# MVC-PHP-5-TEMPLATE

Ini adalah template dasar seperti laravel dan ci dengan konfigurasi yang disesuaikan untuk penggunaan PHP versi 5 yang dibutuhkan
