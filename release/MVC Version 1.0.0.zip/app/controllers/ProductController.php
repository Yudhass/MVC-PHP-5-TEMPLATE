<?php
class ProductController {
    public function show($id) {
        echo "Displaying product with ID: $id";
    }
}